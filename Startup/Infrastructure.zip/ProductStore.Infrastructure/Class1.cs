﻿namespace ProductStore.Infrastructure
{
    public class Class1
    {

    }
}
