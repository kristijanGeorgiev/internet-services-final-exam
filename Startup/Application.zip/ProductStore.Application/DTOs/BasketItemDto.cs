﻿namespace Core.Application.DTOs
{
    public class BasketItemDto
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}