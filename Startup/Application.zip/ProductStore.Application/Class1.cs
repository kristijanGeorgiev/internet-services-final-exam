﻿namespace ProductStore.Application
{
    public class Class1
    {

    }
}
