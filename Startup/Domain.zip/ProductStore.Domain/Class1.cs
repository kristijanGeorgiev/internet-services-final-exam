﻿namespace ProductStore.Domain
{
    public class Class1
    {

    }
}
